config_require(hardware/sensors/hw_sensors);
