#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/snmp_agent.h>
#include <net-snmp/agent/agent_handler.h>
#include <net-snmp/agent/snmp_vars.h>
#include <net-snmp/agent/var_struct.h>
#include "host/hr_partition.h"

int Get_HR_Disk_Label(char *string, size_t str_len, const char *devfull)
{
    return -1;
}
